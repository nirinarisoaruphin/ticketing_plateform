<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\HistoriqueController;
use App\Http\Controllers\MessagesController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PlanningController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WhatsAppController;
use Illuminate\Support\Facades\Route;

// -------------------- Invité --------------------
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

// -------------------- Authentifié --------------------
Route::middleware(['auth', 'must.change.password'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Tickets
    Route::resource('tickets', TicketController::class);
    Route::post('tickets/{ticket}/validate', [TicketController::class, 'validateTicket'])->name('tickets.validate');
    Route::post('tickets/{ticket}/refuse', [TicketController::class, 'refuse'])->name('tickets.refuse');
    Route::post('tickets/{ticket}/return', [TicketController::class, 'returnTicket'])->name('tickets.return');
    Route::post('tickets/{ticket}/comments', [TicketController::class, 'addComment'])->name('tickets.comments.store');
    Route::get('tickets/{ticket}/whatsapp', [WhatsAppController::class, 'share'])->name('tickets.whatsapp');

    // Planning
    Route::get('planning', [PlanningController::class, 'index'])->name('planning.index');
    Route::get('planning/create', [PlanningController::class, 'create'])->name('planning.create');
    Route::post('planning', [PlanningController::class, 'store'])->name('planning.store');
    Route::get('planning/{planning}/edit', [PlanningController::class, 'edit'])->name('planning.edit');
    Route::put('planning/{planning}', [PlanningController::class, 'update'])->name('planning.update');
    Route::post('planning/{planning}/postpone', [PlanningController::class, 'postpone'])->name('planning.postpone');
    Route::post('planning/{planning}/notes', [PlanningController::class, 'addNote'])->name('planning.notes.store');
    Route::get('planning/{planning}/history', [PlanningController::class, 'history'])->name('planning.history');

    // Messages
    Route::get('messages', [MessagesController::class, 'index'])->name('messages.index');
    Route::post('messages', [MessagesController::class, 'store'])->name('messages.store');

    // Notifications
    Route::get('notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('notifications/unread-count', [NotificationController::class, 'unreadCount'])->name('notifications.unread-count');
    Route::post('notifications/{notification}/read', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('notifications/read-all', [NotificationController::class, 'markAllAsRead'])->name('notifications.read-all');

    // Profil
    Route::get('profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::get('profile/password', [ProfileController::class, 'editPassword'])->name('profile.password.edit');
    Route::put('profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password.update');

    // Historique (admin/coordinateur)
    Route::middleware('role:admin,coordinateur')->group(function () {
        Route::get('historique', [HistoriqueController::class, 'index'])->name('historique.index');
        Route::resource('users', UserController::class)->except(['show']);
        Route::post('users/{user}/reset-password', [UserController::class, 'resetPassword'])->name('users.reset-password');
        Route::get('export', [ExportController::class, 'index'])->name('export.index');
        Route::get('export/csv', [ExportController::class, 'exportCsv'])->name('export.csv');
    });
});
