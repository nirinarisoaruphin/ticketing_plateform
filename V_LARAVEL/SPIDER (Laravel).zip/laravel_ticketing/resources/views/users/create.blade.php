@extends('layouts.app')
@section('title', 'Nouvel utilisateur')
@section('content')
<h1 class="text-2xl font-bold mb-6">Nouvel utilisateur</h1>
<form method="POST" action="{{ route('users.store') }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    @csrf
    <div><label class="block text-sm font-medium mb-1">Nom complet</label>
        <input type="text" name="full_name" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Nom d'utilisateur</label>
        <input type="text" name="username" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Email</label>
        <input type="email" name="email" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Téléphone</label>
        <input type="text" name="phone" class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Rôle</label>
        <select name="role" class="w-full border rounded px-3 py-2">
            @foreach(\App\Models\User::ROLES as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach
        </select></div>
    <div><label class="block text-sm font-medium mb-1">Mot de passe temporaire</label>
        <input type="password" name="password" required class="w-full border rounded px-3 py-2"></div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Créer</button>
</form>
@endsection
