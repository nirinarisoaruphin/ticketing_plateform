@extends('layouts.app')
@section('title', 'Modifier utilisateur')
@section('content')
<h1 class="text-2xl font-bold mb-6">Modifier {{ $user->full_name }}</h1>
<form method="POST" action="{{ route('users.update', $user) }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    @csrf @method('PUT')
    <div><label class="block text-sm font-medium mb-1">Nom complet</label>
        <input type="text" name="full_name" value="{{ $user->full_name }}" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Nom d'utilisateur</label>
        <input type="text" name="username" value="{{ $user->username }}" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Email</label>
        <input type="email" name="email" value="{{ $user->email }}" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Téléphone</label>
        <input type="text" name="phone" value="{{ $user->phone }}" class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Rôle</label>
        <select name="role" class="w-full border rounded px-3 py-2">
            @foreach(\App\Models\User::ROLES as $key => $label)<option value="{{ $key }}" @selected($user->role===$key)>{{ $label }}</option>@endforeach
        </select></div>
    <label class="flex items-center gap-2 text-sm">
        <input type="checkbox" name="active" value="1" @checked($user->active)> Compte actif
    </label>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Enregistrer</button>
</form>

<form method="POST" action="{{ route('users.reset-password', $user) }}" class="bg-white rounded-lg shadow p-6 mt-4 max-w-lg space-y-3">
    @csrf
    <label class="block text-sm font-medium">Réinitialiser le mot de passe</label>
    <input type="password" name="password" required class="w-full border rounded px-3 py-2" placeholder="Nouveau mot de passe">
    <button class="bg-amber-600 text-white rounded px-4 py-2 text-sm">Réinitialiser</button>
</form>
@endsection
