@extends('layouts.app')
@section('title', 'Utilisateurs')
@section('content')
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Utilisateurs</h1>
    <a href="{{ route('users.create') }}" class="bg-slate-800 text-white rounded px-4 py-2 text-sm">+ Nouvel utilisateur</a>
</div>
<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50"><tr class="text-left">
            <th class="py-2 px-3">Nom</th><th>Email</th><th>Rôle</th><th>Statut</th><th></th>
        </tr></thead>
        <tbody>
        @foreach($users as $u)
            <tr class="border-t">
                <td class="py-2 px-3">{{ $u->full_name }}</td>
                <td>{{ $u->email }}</td>
                <td>{{ $u->roleLabel() }}</td>
                <td>{{ $u->active ? 'Actif' : 'Inactif' }}</td>
                <td class="text-right px-3">
                    <a href="{{ route('users.edit', $u) }}" class="text-blue-600">Modifier</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $users->links() }}</div>
@endsection
