@extends('layouts.app')
@section('title', 'Historique')
@section('content')
<h1 class="text-2xl font-bold mb-6">Historique des actions</h1>
<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50"><tr class="text-left">
            <th class="py-2 px-3">Date</th><th>Utilisateur</th><th>Action</th><th>Détails</th><th>IP</th>
        </tr></thead>
        <tbody>
        @forelse($logs as $log)
            <tr class="border-t">
                <td class="py-2 px-3">{{ $log->created_at->format('d/m/Y H:i') }}</td>
                <td>{{ $log->user?->full_name ?? 'Système' }}</td>
                <td>{{ $log->action }}</td>
                <td>{{ $log->details }}</td>
                <td>{{ $log->ip_address }}</td>
            </tr>
        @empty
            <tr><td colspan="5" class="text-center py-6 text-gray-500">Aucune entrée.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $logs->links() }}</div>
@endsection
