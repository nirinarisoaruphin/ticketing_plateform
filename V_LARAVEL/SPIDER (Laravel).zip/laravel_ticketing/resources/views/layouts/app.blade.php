<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Plateforme Ticketing')</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">
@auth
    <nav class="bg-slate-800 text-white px-4 py-3 flex items-center justify-between">
        <div class="flex items-center gap-6">
            <a href="{{ route('dashboard') }}" class="font-bold text-lg">🎫 Ticketing</a>
            <a href="{{ route('tickets.index') }}" class="hover:text-slate-300">Tickets</a>
            <a href="{{ route('planning.index') }}" class="hover:text-slate-300">Planning</a>
            <a href="{{ route('messages.index') }}" class="hover:text-slate-300">Messages</a>
            @if(auth()->user()->isCoordinateur())
                <a href="{{ route('users.index') }}" class="hover:text-slate-300">Utilisateurs</a>
                <a href="{{ route('historique.index') }}" class="hover:text-slate-300">Historique</a>
                <a href="{{ route('export.index') }}" class="hover:text-slate-300">Export</a>
            @endif
        </div>
        <div class="flex items-center gap-4">
            <span class="text-sm">{{ auth()->user()->full_name }} — {{ auth()->user()->roleLabel() }}</span>
            <a href="{{ route('profile.edit') }}" class="hover:text-slate-300 text-sm">Profil</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="text-sm hover:text-slate-300">Déconnexion</button>
            </form>
        </div>
    </nav>
@endauth

<main class="max-w-6xl mx-auto px-4 py-6">
    @if(session('success'))
        <div class="mb-4 rounded bg-green-100 text-green-800 px-4 py-2">{{ session('success') }}</div>
    @endif
    @if(session('warning'))
        <div class="mb-4 rounded bg-amber-100 text-amber-800 px-4 py-2">{{ session('warning') }}</div>
    @endif
    @if($errors->any())
        <div class="mb-4 rounded bg-red-100 text-red-800 px-4 py-2">
            <ul class="list-disc list-inside">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @yield('content')
</main>
</body>
</html>
