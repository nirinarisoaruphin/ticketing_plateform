@extends('layouts.app')
@section('title', 'Messages')
@section('content')
<h1 class="text-2xl font-bold mb-6">Messages</h1>
<div class="bg-white rounded-lg shadow divide-y">
    @forelse($messages as $m)
        <div class="p-4">
            <p class="text-sm">{{ $m->content }}</p>
            <p class="text-xs text-gray-500 mt-1">
                {{ $m->user?->full_name }} sur
                <a href="{{ route('tickets.show', $m->ticket) }}" class="text-blue-600">{{ $m->ticket->ticket_number }}</a>
                — {{ $m->created_at->format('d/m/Y H:i') }}
            </p>
        </div>
    @empty
        <p class="p-6 text-center text-gray-500">Aucun message.</p>
    @endforelse
</div>
<div class="mt-4">{{ $messages->links() }}</div>
@endsection
