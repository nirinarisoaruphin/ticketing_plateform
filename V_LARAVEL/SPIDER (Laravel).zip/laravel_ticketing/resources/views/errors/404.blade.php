@extends('layouts.app')
@section('title', 'Page introuvable')
@section('content')
<div class="text-center py-20">
    <h1 class="text-4xl font-bold mb-4">404</h1>
    <p class="text-gray-600 mb-6">Page introuvable.</p>
    <a href="{{ route('dashboard') }}" class="text-blue-600">Retour au tableau de bord</a>
</div>
@endsection
