@extends('layouts.app')
@section('title', 'Ajouter une note')
@section('content')
<h1 class="text-2xl font-bold mb-6">Ajouter une note — {{ $intervention->ticket->ticket_number }}</h1>
<form method="POST" action="{{ route('planning.notes.store', $intervention) }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    @csrf
    <textarea name="note" rows="4" required class="w-full border rounded px-3 py-2" placeholder="Votre note..."></textarea>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Ajouter</button>
</form>
@endsection
