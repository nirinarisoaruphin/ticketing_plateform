@extends('layouts.app')
@section('title', 'Planifier une intervention')
@section('content')
<h1 class="text-2xl font-bold mb-6">Planifier une intervention</h1>
<form method="POST" action="{{ route('planning.store') }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-xl">
    @csrf
    <div><label class="block text-sm font-medium mb-1">Ticket</label>
        <select name="ticket_id" required class="w-full border rounded px-3 py-2">
            @foreach($tickets as $t)
                <option value="{{ $t->id }}" @selected($ticket && $ticket->id===$t->id)>{{ $t->ticket_number }} — {{ $t->title }}</option>
            @endforeach
        </select></div>
    <div><label class="block text-sm font-medium mb-1">Technicien</label>
        <select name="technician_id" required class="w-full border rounded px-3 py-2">
            @foreach($technicians as $u)<option value="{{ $u->id }}">{{ $u->full_name }}</option>@endforeach
        </select></div>
    <div class="grid grid-cols-3 gap-4">
        <div><label class="block text-sm font-medium mb-1">Date</label>
            <input type="date" name="planned_date" required class="w-full border rounded px-3 py-2"></div>
        <div><label class="block text-sm font-medium mb-1">Heure</label>
            <input type="time" name="planned_time" required class="w-full border rounded px-3 py-2"></div>
        <div><label class="block text-sm font-medium mb-1">Durée (min)</label>
            <input type="number" name="duration" value="60" class="w-full border rounded px-3 py-2"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Notes</label>
        <textarea name="notes" rows="3" class="w-full border rounded px-3 py-2"></textarea></div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Planifier</button>
</form>
@endsection
