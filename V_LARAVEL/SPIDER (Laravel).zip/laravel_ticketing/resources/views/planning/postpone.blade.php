@extends('layouts.app')
@section('title', 'Reporter intervention')
@section('content')
<h1 class="text-2xl font-bold mb-6">Reporter l'intervention</h1>
<form method="POST" action="{{ route('planning.postpone', $intervention) }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    @csrf
    <div><label class="block text-sm font-medium mb-1">Nouvelle date</label>
        <input type="date" name="planned_date" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Nouvelle heure</label>
        <input type="time" name="planned_time" required class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Raison</label>
        <textarea name="reason" required class="w-full border rounded px-3 py-2"></textarea></div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Confirmer</button>
</form>
@endsection
