@extends('layouts.app')
@section('title', 'Planning')
@section('content')
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Planning des interventions — {{ $date->translatedFormat('F Y') }}</h1>
    <a href="{{ route('planning.create') }}" class="bg-slate-800 text-white rounded px-4 py-2 text-sm">+ Planifier</a>
</div>
<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50"><tr class="text-left">
            <th class="py-2 px-3">Date</th><th>Heure</th><th>Ticket</th><th>Technicien</th><th>Statut</th><th></th>
        </tr></thead>
        <tbody>
        @forelse($interventions as $i)
            <tr class="border-t">
                <td class="py-2 px-3">{{ $i->planned_date->format('d/m/Y') }}</td>
                <td>{{ \Illuminate\Support\Carbon::parse($i->planned_time)->format('H:i') }}</td>
                <td><a href="{{ route('tickets.show', $i->ticket) }}" class="text-blue-600">{{ $i->ticket->ticket_number }}</a></td>
                <td>{{ $i->technician->full_name }}</td>
                <td>{{ $i->status }}</td>
                <td class="text-right px-3">
                    <a href="{{ route('planning.edit', $i) }}" class="text-blue-600">Modifier</a>
                    <a href="{{ route('planning.history', $i) }}" class="text-gray-600 ml-2">Historique</a>
                </td>
            </tr>
        @empty
            <tr><td colspan="6" class="text-center py-6 text-gray-500">Aucune intervention ce mois-ci.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
