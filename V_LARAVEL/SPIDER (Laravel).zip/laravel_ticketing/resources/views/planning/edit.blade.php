@extends('layouts.app')
@section('title', 'Modifier intervention')
@section('content')
<h1 class="text-2xl font-bold mb-6">Modifier l'intervention — {{ $intervention->ticket->ticket_number }}</h1>
<form method="POST" action="{{ route('planning.update', $intervention) }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-xl">
    @csrf @method('PUT')
    <div><label class="block text-sm font-medium mb-1">Technicien</label>
        <select name="technician_id" class="w-full border rounded px-3 py-2">
            @foreach($technicians as $u)<option value="{{ $u->id }}" @selected($intervention->technician_id===$u->id)>{{ $u->full_name }}</option>@endforeach
        </select></div>
    <div class="grid grid-cols-3 gap-4">
        <div><label class="block text-sm font-medium mb-1">Date</label>
            <input type="date" name="planned_date" value="{{ $intervention->planned_date->format('Y-m-d') }}" class="w-full border rounded px-3 py-2"></div>
        <div><label class="block text-sm font-medium mb-1">Heure</label>
            <input type="time" name="planned_time" value="{{ \Illuminate\Support\Carbon::parse($intervention->planned_time)->format('H:i') }}" class="w-full border rounded px-3 py-2"></div>
        <div><label class="block text-sm font-medium mb-1">Durée</label>
            <input type="number" name="duration" value="{{ $intervention->duration }}" class="w-full border rounded px-3 py-2"></div>
    </div>
    <div><label class="block text-sm font-medium mb-1">Statut</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            @foreach(\App\Models\Intervention::STATUSES as $s)<option value="{{ $s }}" @selected($intervention->status===$s)>{{ $s }}</option>@endforeach
        </select></div>
    <div><label class="block text-sm font-medium mb-1">Notes</label>
        <textarea name="notes" rows="3" class="w-full border rounded px-3 py-2">{{ $intervention->notes }}</textarea></div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Enregistrer</button>
</form>

<form method="POST" action="{{ route('planning.postpone', $intervention) }}" class="bg-white rounded-lg shadow p-6 mt-4 max-w-xl space-y-3">
    @csrf
    <h2 class="font-semibold">Reporter l'intervention</h2>
    <div class="grid grid-cols-2 gap-4">
        <input type="date" name="planned_date" required class="border rounded px-3 py-2">
        <input type="time" name="planned_time" required class="border rounded px-3 py-2">
    </div>
    <textarea name="reason" placeholder="Raison du report" required class="w-full border rounded px-3 py-2"></textarea>
    <button class="bg-amber-600 text-white rounded px-4 py-2 text-sm">Reporter</button>
</form>
@endsection
