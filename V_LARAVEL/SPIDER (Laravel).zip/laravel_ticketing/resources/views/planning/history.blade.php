@extends('layouts.app')
@section('title', 'Historique intervention')
@section('content')
<h1 class="text-2xl font-bold mb-6">Historique — {{ $intervention->ticket->ticket_number }} ({{ $intervention->technician->full_name }})</h1>
<div class="bg-white rounded-lg shadow p-6 space-y-3">
    @forelse($intervention->history as $h)
        <div class="border-l-2 border-slate-300 pl-3">
            <p class="text-sm font-medium">{{ $h->action }}</p>
            <p class="text-sm text-gray-600">{{ $h->details }}</p>
            <p class="text-xs text-gray-500">{{ $h->user?->full_name }} — {{ $h->created_at->format('d/m/Y H:i') }}</p>
        </div>
    @empty
        <p class="text-sm text-gray-500">Aucun historique.</p>
    @endforelse
</div>
@endsection
