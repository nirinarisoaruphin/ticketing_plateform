@extends('layouts.app')
@section('title', 'Notifications')
@section('content')
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Notifications</h1>
    <form method="POST" action="{{ route('notifications.read-all') }}">
        @csrf
        <button class="text-sm text-blue-600">Tout marquer comme lu</button>
    </form>
</div>
<div class="bg-white rounded-lg shadow divide-y">
    @forelse($notifications as $n)
        <div class="p-4 flex justify-between items-center {{ $n->is_read ? '' : 'bg-blue-50' }}">
            <div>
                <p class="text-sm">{{ $n->message }}</p>
                <p class="text-xs text-gray-500">{{ $n->created_at->format('d/m/Y H:i') }}</p>
            </div>
            @if(!$n->is_read)
                <form method="POST" action="{{ route('notifications.read', $n) }}">
                    @csrf
                    <button class="text-xs text-blue-600">Marquer comme lu</button>
                </form>
            @endif
        </div>
    @empty
        <p class="p-6 text-center text-gray-500">Aucune notification.</p>
    @endforelse
</div>
<div class="mt-4">{{ $notifications->links() }}</div>
@endsection
