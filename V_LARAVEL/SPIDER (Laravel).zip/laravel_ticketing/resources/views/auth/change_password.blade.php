@extends('layouts.app')
@section('title', 'Changer le mot de passe')
@section('content')
<div class="max-w-md mx-auto mt-10 bg-white rounded-lg shadow p-8">
    <h1 class="text-2xl font-bold mb-6 text-center">Changer votre mot de passe</h1>
    <form method="POST" action="{{ route('profile.password.update') }}" class="space-y-4">
        @csrf
        @method('PUT')
        <div>
            <label class="block text-sm font-medium mb-1">Mot de passe actuel</label>
            <input type="password" name="current_password" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Nouveau mot de passe</label>
            <input type="password" name="password" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Confirmer</label>
            <input type="password" name="password_confirmation" required class="w-full border rounded px-3 py-2">
        </div>
        <button type="submit" class="w-full bg-slate-800 text-white rounded py-2 hover:bg-slate-700">
            Mettre à jour
        </button>
    </form>
</div>
@endsection
