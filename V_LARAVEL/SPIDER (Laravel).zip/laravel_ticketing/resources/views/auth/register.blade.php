@extends('layouts.app')
@section('title', 'Inscription')
@section('content')
<div class="max-w-md mx-auto mt-10 bg-white rounded-lg shadow p-8">
    <h1 class="text-2xl font-bold mb-6 text-center">Créer un compte</h1>
    <form method="POST" action="{{ route('register') }}" class="space-y-4">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Nom complet</label>
            <input type="text" name="full_name" value="{{ old('full_name') }}" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Nom d'utilisateur</label>
            <input type="text" name="username" value="{{ old('username') }}" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Email</label>
            <input type="email" name="email" value="{{ old('email') }}" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Téléphone</label>
            <input type="text" name="phone" value="{{ old('phone') }}" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Rôle</label>
            <select name="role" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\User::ROLES as $key => $label)
                    <option value="{{ $key }}">{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Mot de passe</label>
            <input type="password" name="password" required class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Confirmer le mot de passe</label>
            <input type="password" name="password_confirmation" required class="w-full border rounded px-3 py-2">
        </div>
        <button type="submit" class="w-full bg-slate-800 text-white rounded py-2 hover:bg-slate-700">
            S'inscrire
        </button>
    </form>
    <p class="text-sm text-center mt-4">Déjà un compte ? <a href="{{ route('login') }}" class="text-blue-600">Se connecter</a></p>
</div>
@endsection
