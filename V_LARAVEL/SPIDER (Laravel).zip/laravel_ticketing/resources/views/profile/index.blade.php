@extends('layouts.app')
@section('title', 'Mon profil')
@section('content')
<h1 class="text-2xl font-bold mb-6">Mon profil</h1>
<form method="POST" action="{{ route('profile.update') }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    @csrf @method('PUT')
    <div><label class="block text-sm font-medium mb-1">Nom complet</label>
        <input type="text" name="full_name" value="{{ $user->full_name }}" class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Email</label>
        <input type="email" name="email" value="{{ $user->email }}" class="w-full border rounded px-3 py-2"></div>
    <div><label class="block text-sm font-medium mb-1">Téléphone</label>
        <input type="text" name="phone" value="{{ $user->phone }}" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Enregistrer</button>
</form>
<a href="{{ route('profile.password.edit') }}" class="inline-block mt-4 text-blue-600 text-sm">Changer mon mot de passe →</a>
@endsection
