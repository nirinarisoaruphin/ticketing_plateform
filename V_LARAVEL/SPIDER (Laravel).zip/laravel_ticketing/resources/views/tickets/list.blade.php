@extends('layouts.app')
@section('title', 'Tickets')
@section('content')
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Tickets</h1>
    <a href="{{ route('tickets.create') }}" class="bg-slate-800 text-white rounded px-4 py-2 text-sm">+ Nouveau ticket</a>
</div>

<form method="GET" class="flex flex-wrap gap-3 mb-4 bg-white p-4 rounded shadow">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Rechercher..." class="border rounded px-3 py-1.5 text-sm">
    <select name="status" class="border rounded px-3 py-1.5 text-sm">
        <option value="">Tous statuts</option>
        @foreach(\App\Models\Ticket::STATUSES as $s)
            <option value="{{ $s }}" @selected(request('status') === $s)>{{ $s }}</option>
        @endforeach
    </select>
    <select name="category" class="border rounded px-3 py-1.5 text-sm">
        <option value="">Toutes catégories</option>
        @foreach(\App\Models\Ticket::CATEGORIES as $c)
            <option value="{{ $c }}" @selected(request('category') === $c)>{{ $c }}</option>
        @endforeach
    </select>
    <button class="bg-gray-200 rounded px-4 py-1.5 text-sm">Filtrer</button>
</form>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50">
            <tr class="text-left">
                <th class="py-2 px-3">N°</th><th>Titre</th><th>Catégorie</th><th>Priorité</th><th>Statut</th><th>Assigné à</th><th>Créé le</th>
            </tr>
        </thead>
        <tbody>
        @forelse($tickets as $t)
            <tr class="border-t hover:bg-gray-50">
                <td class="py-2 px-3"><a href="{{ route('tickets.show', $t) }}" class="text-blue-600 font-medium">{{ $t->ticket_number }}</a></td>
                <td>{{ $t->title }}</td>
                <td>{{ $t->category }}</td>
                <td>{{ $t->priority }}</td>
                <td>{{ $t->status }}</td>
                <td>{{ $t->assignee?->full_name ?? '—' }}</td>
                <td>{{ $t->created_at->format('d/m/Y') }}</td>
            </tr>
        @empty
            <tr><td colspan="7" class="text-center py-6 text-gray-500">Aucun ticket trouvé.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>

<div class="mt-4">{{ $tickets->links() }}</div>
@endsection
