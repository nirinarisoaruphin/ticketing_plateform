@extends('layouts.app')
@section('title', 'Modifier '.$ticket->ticket_number)
@section('content')
<h1 class="text-2xl font-bold mb-6">Modifier {{ $ticket->ticket_number }}</h1>
<form method="POST" action="{{ route('tickets.update', $ticket) }}" class="bg-white rounded-lg shadow p-6 space-y-4">
    @csrf
    @method('PUT')
    <div>
        <label class="block text-sm font-medium mb-1">Titre</label>
        <input type="text" name="title" value="{{ old('title', $ticket->title) }}" required class="w-full border rounded px-3 py-2">
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Description</label>
        <textarea name="description" rows="4" class="w-full border rounded px-3 py-2">{{ old('description', $ticket->description) }}</textarea>
    </div>
    <div class="grid grid-cols-4 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Catégorie</label>
            <select name="category" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::CATEGORIES as $c)<option value="{{ $c }}" @selected($ticket->category===$c)>{{ $c }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Type</label>
            <select name="type_demande" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::TYPES as $t)<option value="{{ $t }}" @selected($ticket->type_demande===$t)>{{ $t }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Priorité</label>
            <select name="priority" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::PRIORITIES as $p)<option value="{{ $p }}" @selected($ticket->priority===$p)>{{ $p }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Statut</label>
            <select name="status" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::STATUSES as $s)<option value="{{ $s }}" @selected($ticket->status===$s)>{{ $s }}</option>@endforeach
            </select>
        </div>
    </div>
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Client</label>
            <input type="text" name="client_name" value="{{ old('client_name', $ticket->client_name) }}" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Assigner à</label>
            <select name="assigned_to" class="w-full border rounded px-3 py-2">
                <option value="">— Non assigné —</option>
                @foreach($users as $u)<option value="{{ $u->id }}" @selected($ticket->assigned_to===$u->id)>{{ $u->full_name }}</option>@endforeach
            </select>
        </div>
    </div>
    <div class="flex justify-between">
        <button type="submit" class="bg-slate-800 text-white rounded px-6 py-2">Enregistrer</button>
        <form method="POST" action="{{ route('tickets.destroy', $ticket) }}" onsubmit="return confirm('Supprimer ce ticket ?')">
            @csrf @method('DELETE')
            <button class="bg-red-600 text-white rounded px-6 py-2">Supprimer</button>
        </form>
    </div>
</form>
@endsection
