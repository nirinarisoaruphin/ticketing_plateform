@extends('layouts.app')
@section('title', 'Nouveau ticket')
@section('content')
<h1 class="text-2xl font-bold mb-6">Nouveau ticket</h1>
<form method="POST" action="{{ route('tickets.store') }}" enctype="multipart/form-data" class="bg-white rounded-lg shadow p-6 space-y-4">
    @csrf
    <div>
        <label class="block text-sm font-medium mb-1">Titre</label>
        <input type="text" name="title" value="{{ old('title') }}" required class="w-full border rounded px-3 py-2">
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Description</label>
        <textarea name="description" rows="4" class="w-full border rounded px-3 py-2">{{ old('description') }}</textarea>
    </div>
    <div class="grid grid-cols-3 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Catégorie</label>
            <select name="category" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::CATEGORIES as $c)<option value="{{ $c }}">{{ $c }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Type de demande</label>
            <select name="type_demande" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::TYPES as $t)<option value="{{ $t }}">{{ $t }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Priorité</label>
            <select name="priority" class="w-full border rounded px-3 py-2">
                @foreach(\App\Models\Ticket::PRIORITIES as $p)<option value="{{ $p }}" @selected($p==='moyenne')>{{ $p }}</option>@endforeach
            </select>
        </div>
    </div>
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Client</label>
            <input type="text" name="client_name" value="{{ old('client_name') }}" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Assigner à</label>
            <select name="assigned_to" class="w-full border rounded px-3 py-2">
                <option value="">— Non assigné —</option>
                @foreach($users as $u)<option value="{{ $u->id }}">{{ $u->full_name }} ({{ $u->roleLabel() }})</option>@endforeach
            </select>
        </div>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Adresse client</label>
        <textarea name="adresse_client" rows="2" class="w-full border rounded px-3 py-2">{{ old('adresse_client') }}</textarea>
    </div>
    <div class="grid grid-cols-3 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Date de visite</label>
            <input type="date" name="visite_date" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Heure de visite</label>
            <input type="time" name="visite_heure" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Pièce jointe</label>
            <input type="file" name="attachment" class="w-full border rounded px-3 py-2">
        </div>
    </div>
    <button type="submit" class="bg-slate-800 text-white rounded px-6 py-2">Créer le ticket</button>
</form>
@endsection
