@extends('layouts.app')
@section('title', $ticket->ticket_number)
@section('content')
<div class="flex justify-between items-start mb-6">
    <div>
        <h1 class="text-2xl font-bold">{{ $ticket->ticket_number }} — {{ $ticket->title }}</h1>
        <p class="text-sm text-gray-500">Créé par {{ $ticket->creator?->full_name }} le {{ $ticket->created_at->format('d/m/Y H:i') }}</p>
    </div>
    <div class="flex items-center gap-2">
        <button type="button" onclick="document.getElementById('qrModal').classList.remove('hidden')"
                class="border border-gray-300 rounded px-4 py-2 text-sm hover:bg-gray-50">
            QR Code
        </button>
        <a href="{{ route('tickets.edit', $ticket) }}" class="bg-slate-800 text-white rounded px-4 py-2 text-sm">Modifier</a>
    </div>
</div>

@php
    $qrTicketUrl = route('tickets.show', $ticket);
    $qrImageUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=' . urlencode($qrTicketUrl);
@endphp
<div id="qrModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
     onclick="if(event.target === this) this.classList.add('hidden')">
    <div class="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-semibold text-gray-900">QR Code du ticket</h3>
            <button type="button" onclick="document.getElementById('qrModal').classList.add('hidden')"
                    class="text-gray-400 hover:text-gray-600">✕</button>
        </div>
        <img src="{{ $qrImageUrl }}" alt="QR Code ticket {{ $ticket->ticket_number }}"
             class="mx-auto rounded-lg border border-gray-200" width="260" height="260" id="qrCodeImg">
        <p class="text-sm text-gray-500 mt-3">{{ $ticket->ticket_number }}</p>
        <p class="text-xs text-gray-400 mt-1">Scannez pour ouvrir directement ce ticket</p>
        <div class="flex gap-2 mt-4">
            <a href="{{ $qrImageUrl }}" download="qrcode_{{ $ticket->ticket_number }}.png"
               class="flex-1 border border-gray-300 rounded px-3 py-1.5 text-sm hover:bg-gray-50">Télécharger</a>
            <button type="button" onclick="window.print()" class="flex-1 border border-gray-300 rounded px-3 py-1.5 text-sm hover:bg-gray-50">Imprimer</button>
        </div>
    </div>
</div>

<div class="grid grid-cols-3 gap-6">
    <div class="col-span-2 space-y-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="font-semibold mb-2">Description</h2>
            <p class="text-sm whitespace-pre-line">{{ $ticket->description ?: '—' }}</p>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="font-semibold mb-4">Commentaires</h2>
            <form method="POST" action="{{ route('tickets.comments.store', $ticket) }}" class="mb-4">
                @csrf
                <textarea name="content" rows="2" placeholder="Ajouter un commentaire..." class="w-full border rounded px-3 py-2 text-sm" required></textarea>
                <button class="mt-2 bg-slate-800 text-white rounded px-4 py-1.5 text-sm">Envoyer</button>
            </form>
            <div class="space-y-3">
                @forelse($ticket->comments as $c)
                    <div class="border-l-2 border-slate-300 pl-3">
                        <p class="text-sm">{{ $c->content }}</p>
                        <p class="text-xs text-gray-500">{{ $c->user?->full_name }} — {{ $c->created_at->format('d/m/Y H:i') }}</p>
                    </div>
                @empty
                    <p class="text-sm text-gray-500">Aucun commentaire.</p>
                @endforelse
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <div class="bg-white rounded-lg shadow p-4 text-sm space-y-2">
            <p><strong>Statut :</strong> {{ $ticket->status }}</p>
            <p><strong>Priorité :</strong> {{ $ticket->priority }}</p>
            <p><strong>Catégorie :</strong> {{ $ticket->category }}</p>
            <p><strong>Validation :</strong> {{ $ticket->validation_status }}</p>
            <p><strong>Assigné à :</strong> {{ $ticket->assignee?->full_name ?? '—' }}</p>
            <p><strong>Client :</strong> {{ $ticket->client_name ?? '—' }}</p>
        </div>

        @if(auth()->user()->isCoordinateur())
        <div class="bg-white rounded-lg shadow p-4 space-y-2">
            <form method="POST" action="{{ route('tickets.validate', $ticket) }}">
                @csrf
                <button class="w-full bg-green-600 text-white rounded px-3 py-2 text-sm">Valider</button>
            </form>
            <form method="POST" action="{{ route('tickets.refuse', $ticket) }}" onsubmit="return confirm('Motif du refus ?')">
                @csrf
                <input type="hidden" name="validation_comment" value="Refusé par le coordinateur">
                <button class="w-full bg-red-600 text-white rounded px-3 py-2 text-sm">Refuser</button>
            </form>
        </div>
        @endif

        <a href="{{ route('planning.create', ['ticket_id' => $ticket->id]) }}" class="block text-center bg-amber-600 text-white rounded px-3 py-2 text-sm">
            Planifier une intervention
        </a>

        <div class="bg-white rounded-lg shadow p-4 space-y-2">
            <h2 class="font-semibold text-sm mb-1">Partager sur WhatsApp</h2>
            <form method="GET" action="{{ route('tickets.whatsapp', $ticket) }}" class="space-y-2">
                <select name="action" class="w-full border rounded px-2 py-1.5 text-sm">
                    <option value="general">Action effectuée</option>
                    <option value="resolu">Ticket résolu</option>
                    <option value="en_cours">Ticket en cours</option>
                    <option value="en_attente">Ticket en attente</option>
                    <option value="signaler_probleme">Problème signalé</option>
                    <option value="commentaire">Nouveau commentaire</option>
                    <option value="valide">Ticket validé</option>
                    <option value="refuse">Ticket refusé</option>
                </select>
                <button class="w-full flex items-center justify-center gap-2 bg-[#25D366] text-white rounded px-3 py-2 text-sm font-medium">
                    Partager sur WhatsApp
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
