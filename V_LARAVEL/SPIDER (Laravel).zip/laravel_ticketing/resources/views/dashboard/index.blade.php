@extends('layouts.app')
@section('title', 'Tableau de bord')
@section('content')
<h1 class="text-2xl font-bold mb-6">Tableau de bord</h1>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    @foreach([
        'total' => ['Total', 'bg-slate-700'],
        'nouveau' => ['Nouveaux', 'bg-blue-600'],
        'en_cours' => ['En cours', 'bg-amber-600'],
        'en_attente' => ['En attente', 'bg-orange-600'],
        'resolu' => ['Résolus', 'bg-green-600'],
        'cloture' => ['Clôturés', 'bg-gray-600'],
        'critique' => ['Critiques', 'bg-red-600'],
    ] as $key => [$label, $color])
        <div class="{{ $color }} text-white rounded-lg p-4 shadow">
            <div class="text-3xl font-bold">{{ $stats[$key] }}</div>
            <div class="text-sm opacity-90">{{ $label }}</div>
        </div>
    @endforeach
</div>

<div class="bg-white rounded-lg shadow p-6">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-semibold">Tickets récents</h2>
        <a href="{{ route('tickets.create') }}" class="bg-slate-800 text-white rounded px-4 py-2 text-sm">+ Nouveau ticket</a>
    </div>
    <table class="w-full text-sm">
        <thead>
            <tr class="text-left border-b">
                <th class="py-2">N°</th><th>Titre</th><th>Statut</th><th>Priorité</th><th>Assigné à</th><th>Créé le</th>
            </tr>
        </thead>
        <tbody>
        @foreach($recentTickets as $t)
            <tr class="border-b hover:bg-gray-50">
                <td class="py-2"><a href="{{ route('tickets.show', $t) }}" class="text-blue-600">{{ $t->ticket_number }}</a></td>
                <td>{{ $t->title }}</td>
                <td>{{ $t->status }}</td>
                <td>{{ $t->priority }}</td>
                <td>{{ $t->assignee?->full_name ?? '—' }}</td>
                <td>{{ $t->created_at->format('d/m/Y') }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
