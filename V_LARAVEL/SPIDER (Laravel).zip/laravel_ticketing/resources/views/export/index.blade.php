@extends('layouts.app')
@section('title', 'Export')
@section('content')
<h1 class="text-2xl font-bold mb-6">Export des tickets</h1>
<form method="GET" action="{{ route('export.csv') }}" class="bg-white rounded-lg shadow p-6 space-y-4 max-w-lg">
    <div><label class="block text-sm font-medium mb-1">Statut</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            <option value="">Tous</option>
            @foreach(\App\Models\Ticket::STATUSES as $s)<option value="{{ $s }}">{{ $s }}</option>@endforeach
        </select></div>
    <div><label class="block text-sm font-medium mb-1">Catégorie</label>
        <select name="category" class="w-full border rounded px-3 py-2">
            <option value="">Toutes</option>
            @foreach(\App\Models\Ticket::CATEGORIES as $c)<option value="{{ $c }}">{{ $c }}</option>@endforeach
        </select></div>
    <div class="grid grid-cols-2 gap-4">
        <div><label class="block text-sm font-medium mb-1">Du</label>
            <input type="date" name="date_from" class="w-full border rounded px-3 py-2"></div>
        <div><label class="block text-sm font-medium mb-1">Au</label>
            <input type="date" name="date_to" class="w-full border rounded px-3 py-2"></div>
    </div>
    <button class="bg-slate-800 text-white rounded px-6 py-2">Télécharger le CSV</button>
</form>
@endsection
