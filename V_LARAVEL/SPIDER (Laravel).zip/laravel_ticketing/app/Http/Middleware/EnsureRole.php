<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureRole
{
    /**
     * Autorise l'accès si l'utilisateur a un des rôles fournis.
     * Usage dans les routes : ->middleware('role:admin,coordinateur')
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user || (! in_array($user->role, $roles) && ! $user->isAdmin())) {
            abort(403, "Vous n'avez pas les droits pour accéder à cette page.");
        }

        return $next($request);
    }
}
