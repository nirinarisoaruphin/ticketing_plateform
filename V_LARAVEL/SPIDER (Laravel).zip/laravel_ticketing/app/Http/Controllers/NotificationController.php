<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index(Request $request)
    {
        $notifications = $request->user()->notifications()
            ->orderByDesc('created_at')->paginate(20);

        return view('notifications.dropdown', compact('notifications'));
    }

    public function markAsRead(Request $request, Notification $notification)
    {
        abort_unless($notification->user_id === $request->user()->id, 403);
        $notification->update(['is_read' => true]);

        return back();
    }

    public function markAllAsRead(Request $request)
    {
        $request->user()->notifications()->unread()->update(['is_read' => true]);

        return back()->with('success', 'Notifications marquées comme lues.');
    }

    public function unreadCount(Request $request)
    {
        return response()->json([
            'count' => $request->user()->notifications()->unread()->count(),
        ]);
    }
}
