<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Services\WhatsAppImageGenerator;
use Illuminate\Http\Request;

class WhatsAppController extends Controller
{
    /**
     * Génère une image récapitulative du ticket et redirige vers WhatsApp
     * (wa.me) avec un message pré-rempli, comme dans la version legacy.
     */
    public function share(Request $request, Ticket $ticket, WhatsAppImageGenerator $generator)
    {
        $actionType = $request->query('action', 'general');
        $content = (string) $request->query('content', '');
        $senderName = $request->user()->full_name ?? 'Utilisateur';

        try {
            $imageData = $generator->generateActionImage($ticket, $actionType, $senderName, $content);

            return redirect()->away($imageData['whatsapp_url']);
        } catch (\Throwable $e) {
            report($e);

            return redirect()
                ->route('tickets.show', $ticket)
                ->with('warning', "Erreur lors de la génération de l'image WhatsApp.");
        }
    }
}
