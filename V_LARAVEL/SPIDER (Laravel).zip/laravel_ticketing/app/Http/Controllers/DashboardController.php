<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $baseQuery = $user->isCoordinateur()
            ? Ticket::query()
            : Ticket::where('created_by', $user->id)->orWhere('assigned_to', $user->id);

        $stats = [
            'total' => (clone $baseQuery)->count(),
            'nouveau' => (clone $baseQuery)->where('status', 'nouveau')->count(),
            'en_cours' => (clone $baseQuery)->where('status', 'en_cours')->count(),
            'en_attente' => (clone $baseQuery)->where('status', 'en_attente')->count(),
            'resolu' => (clone $baseQuery)->where('status', 'resolu')->count(),
            'cloture' => (clone $baseQuery)->where('status', 'cloture')->count(),
            'critique' => (clone $baseQuery)->where('priority', 'critique')->count(),
        ];

        $recentTickets = (clone $baseQuery)->with(['creator', 'assignee'])
            ->orderByDesc('created_at')->limit(10)->get();

        $byCategory = (clone $baseQuery)->selectRaw('category, count(*) as total')
            ->groupBy('category')->pluck('total', 'category');

        return view('dashboard.index', compact('stats', 'recentTickets', 'byCategory'));
    }
}
