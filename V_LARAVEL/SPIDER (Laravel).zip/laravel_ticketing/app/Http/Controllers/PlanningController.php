<?php

namespace App\Http\Controllers;

use App\Models\Intervention;
use App\Models\InterventionHistory;
use App\Models\Notification;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Http\Request;

class PlanningController extends Controller
{
    public function index(Request $request)
    {
        $date = $request->date ? \Carbon\Carbon::parse($request->date) : now();

        $interventions = Intervention::with(['ticket', 'technician'])
            ->whereMonth('planned_date', $date->month)
            ->whereYear('planned_date', $date->year)
            ->when($request->technician_id, fn ($q) => $q->where('technician_id', $request->technician_id))
            ->orderBy('planned_date')->orderBy('planned_time')
            ->get();

        $technicians = User::where('active', true)->orderBy('full_name')->get();

        return view('planning.index', compact('interventions', 'technicians', 'date'));
    }

    public function create(Request $request)
    {
        $tickets = Ticket::whereNotIn('status', ['cloture'])->orderByDesc('created_at')->get();
        $technicians = User::where('active', true)->orderBy('full_name')->get();
        $ticket = $request->ticket_id ? Ticket::find($request->ticket_id) : null;

        return view('planning.create', compact('tickets', 'technicians', 'ticket'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'ticket_id' => ['required', 'exists:tickets,id'],
            'technician_id' => ['required', 'exists:users,id'],
            'planned_date' => ['required', 'date'],
            'planned_time' => ['required'],
            'duration' => ['nullable', 'integer', 'min:15'],
            'notes' => ['nullable', 'string'],
        ]);

        $intervention = Intervention::create($data);

        InterventionHistory::create([
            'intervention_id' => $intervention->id,
            'user_id' => $request->user()->id,
            'action' => 'creation',
            'details' => 'Intervention planifiée',
        ]);

        Notification::create([
            'user_id' => $intervention->technician_id,
            'ticket_id' => $intervention->ticket_id,
            'message' => "Nouvelle intervention planifiée le {$intervention->planned_date->format('d/m/Y')}",
            'link' => route('planning.index'),
            'type' => 'planning',
        ]);

        return redirect()->route('planning.index')->with('success', 'Intervention planifiée.');
    }

    public function edit(Intervention $planning)
    {
        $technicians = User::where('active', true)->orderBy('full_name')->get();

        return view('planning.edit', ['intervention' => $planning, 'technicians' => $technicians]);
    }

    public function update(Request $request, Intervention $planning)
    {
        $data = $request->validate([
            'technician_id' => ['required', 'exists:users,id'],
            'planned_date' => ['required', 'date'],
            'planned_time' => ['required'],
            'duration' => ['nullable', 'integer', 'min:15'],
            'status' => ['required', 'in:'.implode(',', Intervention::STATUSES)],
            'notes' => ['nullable', 'string'],
        ]);

        $planning->update($data);

        InterventionHistory::create([
            'intervention_id' => $planning->id,
            'user_id' => $request->user()->id,
            'action' => 'modification',
            'details' => 'Intervention modifiée',
        ]);

        return redirect()->route('planning.index')->with('success', 'Intervention mise à jour.');
    }

    public function postpone(Request $request, Intervention $planning)
    {
        $data = $request->validate([
            'planned_date' => ['required', 'date'],
            'planned_time' => ['required'],
            'reason' => ['required', 'string'],
        ]);

        $oldDate = $planning->planned_date->format('d/m/Y');
        $planning->update(['planned_date' => $data['planned_date'], 'planned_time' => $data['planned_time']]);

        InterventionHistory::create([
            'intervention_id' => $planning->id,
            'user_id' => $request->user()->id,
            'action' => 'report',
            'details' => "Reportée du {$oldDate} — Raison: {$data['reason']}",
        ]);

        return redirect()->route('planning.index')->with('success', 'Intervention reportée.');
    }

    public function addNote(Request $request, Intervention $planning)
    {
        $data = $request->validate(['note' => ['required', 'string']]);

        InterventionHistory::create([
            'intervention_id' => $planning->id,
            'user_id' => $request->user()->id,
            'action' => 'note',
            'details' => $data['note'],
        ]);

        return back()->with('success', 'Note ajoutée.');
    }

    public function history(Intervention $planning)
    {
        $planning->load('history.user', 'ticket', 'technician');

        return view('planning.history', ['intervention' => $planning]);
    }
}
