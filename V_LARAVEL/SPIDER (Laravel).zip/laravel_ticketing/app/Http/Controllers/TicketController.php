<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Log;
use App\Models\Notification;
use App\Models\Ticket;
use App\Models\TicketAssignment;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $query = $user->isCoordinateur()
            ? Ticket::query()
            : Ticket::where('created_by', $user->id)->orWhere('assigned_to', $user->id);

        $query->status($request->status)
            ->category($request->category)
            ->priority($request->priority);

        if ($search = $request->search) {
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                    ->orWhere('ticket_number', 'like', "%{$search}%")
                    ->orWhere('client_name', 'like', "%{$search}%");
            });
        }

        $tickets = $query->with(['creator', 'assignee'])
            ->orderByDesc('created_at')->paginate(20)->withQueryString();

        return view('tickets.list', compact('tickets'));
    }

    public function create()
    {
        $users = User::where('active', true)->orderBy('full_name')->get();

        return view('tickets.create', compact('users'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'category' => ['required', 'in:'.implode(',', Ticket::CATEGORIES)],
            'type_demande' => ['required', 'in:'.implode(',', Ticket::TYPES)],
            'priority' => ['required', 'in:'.implode(',', Ticket::PRIORITIES)],
            'client_name' => ['nullable', 'string', 'max:100'],
            'adresse_client' => ['nullable', 'string'],
            'interlocuteur' => ['nullable', 'string', 'max:100'],
            'contact_technique' => ['nullable', 'string', 'max:100'],
            'lieu_visite' => ['nullable', 'string', 'max:255'],
            'visite_date' => ['nullable', 'date'],
            'visite_heure' => ['nullable'],
            'moyen_transport' => ['nullable', 'string', 'max:50'],
            'elements_complement' => ['nullable', 'string'],
            'assigned_to' => ['nullable', 'exists:users,id'],
            'attachment' => ['nullable', 'file', 'max:10240'],
        ]);

        $data['ticket_number'] = Ticket::generateTicketNumber();
        $data['created_by'] = $request->user()->id;
        $data['status'] = $data['assigned_to'] ?? null ? 'assigne' : 'nouveau';

        if ($request->hasFile('attachment')) {
            $data['attachment'] = $request->file('attachment')->store('tickets', 'public');
        }

        $ticket = Ticket::create($data);

        if ($ticket->assigned_to) {
            TicketAssignment::create([
                'ticket_id' => $ticket->id,
                'user_id' => $ticket->assigned_to,
                'assigned_by' => $request->user()->id,
            ]);
            Notification::create([
                'user_id' => $ticket->assigned_to,
                'ticket_id' => $ticket->id,
                'message' => "Nouveau ticket assigné : {$ticket->ticket_number}",
                'link' => route('tickets.show', $ticket),
                'type' => 'assignation',
            ]);
        }

        Log::record('ticket_create', "Ticket créé: {$ticket->ticket_number}");

        return redirect()->route('tickets.show', $ticket)->with('success', 'Ticket créé avec succès.');
    }

    public function show(Ticket $ticket)
    {
        $ticket->load(['creator', 'assignee', 'comments.user', 'interventions.technician']);
        $users = User::where('active', true)->orderBy('full_name')->get();

        return view('tickets.show', compact('ticket', 'users'));
    }

    public function edit(Ticket $ticket)
    {
        $users = User::where('active', true)->orderBy('full_name')->get();

        return view('tickets.edit', compact('ticket', 'users'));
    }

    public function update(Request $request, Ticket $ticket)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'category' => ['required', 'in:'.implode(',', Ticket::CATEGORIES)],
            'type_demande' => ['required', 'in:'.implode(',', Ticket::TYPES)],
            'priority' => ['required', 'in:'.implode(',', Ticket::PRIORITIES)],
            'status' => ['required', 'in:'.implode(',', Ticket::STATUSES)],
            'client_name' => ['nullable', 'string', 'max:100'],
            'assigned_to' => ['nullable', 'exists:users,id'],
        ]);

        $previousAssignee = $ticket->assigned_to;
        $previousStatus = $ticket->status;

        if ($data['status'] === 'resolu' && $previousStatus !== 'resolu') {
            $data['resolved_at'] = now();
        }

        $ticket->update($data);

        if (! empty($data['assigned_to']) && $data['assigned_to'] != $previousAssignee) {
            TicketAssignment::create([
                'ticket_id' => $ticket->id,
                'user_id' => $data['assigned_to'],
                'assigned_by' => $request->user()->id,
            ]);
            Notification::create([
                'user_id' => $data['assigned_to'],
                'ticket_id' => $ticket->id,
                'message' => "Ticket assigné : {$ticket->ticket_number}",
                'link' => route('tickets.show', $ticket),
                'type' => 'assignation',
            ]);
        }

        if ($data['status'] !== $previousStatus) {
            Notification::create([
                'user_id' => $ticket->created_by,
                'ticket_id' => $ticket->id,
                'message' => "Statut du ticket {$ticket->ticket_number} changé en {$data['status']}",
                'link' => route('tickets.show', $ticket),
                'type' => 'status',
            ]);
        }

        Log::record('ticket_update', "Ticket modifié: {$ticket->ticket_number}");

        return redirect()->route('tickets.show', $ticket)->with('success', 'Ticket mis à jour.');
    }

    public function destroy(Ticket $ticket)
    {
        Log::record('ticket_delete', "Ticket supprimé: {$ticket->ticket_number}");
        if ($ticket->attachment) {
            Storage::disk('public')->delete($ticket->attachment);
        }
        $ticket->delete();

        return redirect()->route('tickets.index')->with('success', 'Ticket supprimé.');
    }

    public function validateTicket(Request $request, Ticket $ticket)
    {
        $ticket->update([
            'validation_status' => 'valide',
            'validated_by' => $request->user()->id,
            'validated_at' => now(),
        ]);

        Notification::create([
            'user_id' => $ticket->created_by,
            'ticket_id' => $ticket->id,
            'message' => "Ticket {$ticket->ticket_number} validé",
            'link' => route('tickets.show', $ticket),
            'type' => 'validation',
        ]);

        return back()->with('success', 'Ticket validé.');
    }

    public function refuse(Request $request, Ticket $ticket)
    {
        $data = $request->validate(['validation_comment' => ['required', 'string']]);

        $ticket->update([
            'validation_status' => 'refuse',
            'refused_by' => $request->user()->id,
            'refused_at' => now(),
            'validation_comment' => $data['validation_comment'],
        ]);

        Notification::create([
            'user_id' => $ticket->created_by,
            'ticket_id' => $ticket->id,
            'message' => "Ticket {$ticket->ticket_number} refusé : {$data['validation_comment']}",
            'link' => route('tickets.show', $ticket),
            'type' => 'validation',
        ]);

        return back()->with('success', 'Ticket refusé.');
    }

    public function returnTicket(Request $request, Ticket $ticket)
    {
        $data = $request->validate(['return_message' => ['required', 'string']]);

        $ticket->increment('reformulation_count');
        $ticket->update([
            'return_message' => $data['return_message'],
            'returned_by' => $request->user()->id,
            'returned_at' => now(),
            'status' => 'en_attente',
        ]);

        Notification::create([
            'user_id' => $ticket->created_by,
            'ticket_id' => $ticket->id,
            'message' => "Ticket {$ticket->ticket_number} retourné pour reformulation",
            'link' => route('tickets.show', $ticket),
            'type' => 'action',
        ]);

        return back()->with('success', 'Ticket retourné pour reformulation.');
    }

    public function addComment(Request $request, Ticket $ticket)
    {
        $data = $request->validate([
            'content' => ['required', 'string'],
            'is_action' => ['nullable', 'boolean'],
        ]);

        $comment = Comment::create([
            'ticket_id' => $ticket->id,
            'user_id' => $request->user()->id,
            'content' => $data['content'],
            'is_action' => $request->boolean('is_action'),
        ]);

        $notifyUserId = $ticket->created_by === $request->user()->id ? $ticket->assigned_to : $ticket->created_by;

        if ($notifyUserId) {
            Notification::create([
                'user_id' => $notifyUserId,
                'ticket_id' => $ticket->id,
                'message' => "Nouveau commentaire sur {$ticket->ticket_number}",
                'link' => route('tickets.show', $ticket),
                'type' => 'comment',
            ]);
        }

        return back()->with('success', 'Commentaire ajouté.');
    }
}
