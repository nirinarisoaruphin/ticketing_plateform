<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ExportController extends Controller
{
    public function index()
    {
        return view('export.index');
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        $tickets = Ticket::with(['creator', 'assignee'])
            ->status($request->status)
            ->category($request->category)
            ->when($request->date_from, fn ($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn ($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->get();

        $filename = 'tickets_export_'.now()->format('Ymd_His').'.csv';

        $callback = function () use ($tickets) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['Numéro', 'Titre', 'Catégorie', 'Priorité', 'Statut', 'Créé par', 'Assigné à', 'Client', 'Créé le']);

            foreach ($tickets as $t) {
                fputcsv($handle, [
                    $t->ticket_number, $t->title, $t->category, $t->priority, $t->status,
                    $t->creator?->full_name, $t->assignee?->full_name, $t->client_name,
                    $t->created_at?->format('d/m/Y H:i'),
                ]);
            }

            fclose($handle);
        };

        return response()->streamDownload($callback, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }
}
