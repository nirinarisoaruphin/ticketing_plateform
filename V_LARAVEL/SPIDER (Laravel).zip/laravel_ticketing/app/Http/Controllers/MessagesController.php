<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Notification;
use Illuminate\Http\Request;

class MessagesController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $messages = Comment::with(['ticket', 'user'])
            ->whereHas('ticket', fn ($q) => $q->where('created_by', $user->id)->orWhere('assigned_to', $user->id))
            ->orderByDesc('created_at')
            ->paginate(20);

        return view('messages.index', compact('messages'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'ticket_id' => ['required', 'exists:tickets,id'],
            'content' => ['required', 'string'],
        ]);

        $comment = Comment::create([
            'ticket_id' => $data['ticket_id'],
            'user_id' => $request->user()->id,
            'content' => $data['content'],
        ]);

        return back()->with('success', 'Message envoyé.');
    }
}
