<?php

namespace App\Http\Controllers;

use App\Models\LoginAttempt;
use App\Models\Log;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        $throttleKey = strtolower($credentials['email']).'|'.$request->ip();

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);
            throw ValidationException::withMessages([
                'email' => "Trop de tentatives. Réessayez dans {$seconds} secondes.",
            ]);
        }

        $user = User::where('email', $credentials['email'])->first();

        if (! $user || ! Hash::check($credentials['password'], $user->password) || ! $user->active) {
            RateLimiter::hit($throttleKey, 60);
            LoginAttempt::create(['email' => $credentials['email'], 'success' => false, 'ip_address' => $request->ip()]);

            throw ValidationException::withMessages([
                'email' => 'Identifiants incorrects ou compte désactivé.',
            ]);
        }

        RateLimiter::clear($throttleKey);
        Auth::login($user, $request->boolean('remember'));
        $request->session()->regenerate();

        LoginAttempt::create(['email' => $credentials['email'], 'success' => true, 'ip_address' => $request->ip()]);
        Log::record('login', 'Connexion réussie');

        if ($user->must_change_password) {
            return redirect()->route('profile.password.edit');
        }

        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $request)
    {
        Log::record('logout', 'Déconnexion');
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'username' => ['required', 'string', 'max:50', 'unique:users,username'],
            'email' => ['required', 'email', 'max:100', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'full_name' => ['required', 'string', 'max:100'],
            'phone' => ['nullable', 'string', 'max:20'],
            'role' => ['required', 'in:'.implode(',', array_keys(User::ROLES))],
        ]);

        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);

        Log::record('register', 'Nouvel utilisateur créé: '.$user->username, $user->id);

        return redirect()->route('login')->with('success', 'Compte créé, vous pouvez vous connecter.');
    }
}
