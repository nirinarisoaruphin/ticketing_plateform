<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    // Rôles disponibles (repris tel quel du schéma d'origine)
    public const ROLES = [
        'admin' => 'Administrateur',
        'coordinateur' => 'Coordinateur',
        'responsable_support_technique' => 'Responsable Support Technique',
        'responsable_sav' => 'Responsable SAV',
        'responsable_travaux' => 'Responsable Travaux',
        'commercial' => 'Commercial',
        'charge_etude_electricite' => "Chargé d'étude Électricité",
        'charge_etude_courant_faible' => "Chargé d'étude Courant Faible",
        'charge_etude_climatisation' => "Chargé d'étude Climatisation",
    ];

    protected $fillable = [
        'username', 'email', 'password', 'full_name', 'phone',
        'role', 'must_change_password', 'active',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'must_change_password' => 'boolean',
            'active' => 'boolean',
            'password' => 'hashed',
        ];
    }

    public function ticketsCreated(): HasMany
    {
        return $this->hasMany(Ticket::class, 'created_by');
    }

    public function ticketsAssigned(): HasMany
    {
        return $this->hasMany(Ticket::class, 'assigned_to');
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(TicketAssignment::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class);
    }

    public function interventions(): HasMany
    {
        return $this->hasMany(Intervention::class, 'technician_id');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(Log::class);
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isCoordinateur(): bool
    {
        return in_array($this->role, ['admin', 'coordinateur']);
    }

    public function roleLabel(): string
    {
        return self::ROLES[$this->role] ?? $this->role;
    }
}
