<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InterventionHistory extends Model
{
    public $timestamps = false;
    protected $table = 'intervention_history';

    protected $fillable = ['intervention_id', 'user_id', 'action', 'details'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function intervention(): BelongsTo
    {
        return $this->belongsTo(Intervention::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
