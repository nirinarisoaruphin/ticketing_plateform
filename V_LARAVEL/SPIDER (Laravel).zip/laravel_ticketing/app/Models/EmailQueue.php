<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailQueue extends Model
{
    public $timestamps = false;
    protected $table = 'email_queue';

    protected $fillable = [
        'ticket_id', 'ticket_number', 'recipient_email', 'recipient_name',
        'subject', 'message', 'status', 'error', 'processed_at',
    ];

    protected function casts(): array
    {
        return ['created_at' => 'datetime', 'processed_at' => 'datetime'];
    }
}
