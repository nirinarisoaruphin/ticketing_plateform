<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;

class Ticket extends Model
{
    use HasFactory;

    public const CATEGORIES = ['support_technique', 'bureau_etude', 'sav', 'travaux'];

    public const TYPES = [
        'etude', 'visite', 'visite_etude', 'visite_etude_installation', 'panne',
        'installation', 'maintenance', 'sav', 'travaux', 'demande_info', 'autre',
    ];

    public const PRIORITIES = ['basse', 'moyenne', 'haute', 'critique'];

    public const STATUSES = ['nouveau', 'assigne', 'en_cours', 'en_attente', 'resolu', 'cloture'];

    protected $fillable = [
        'ticket_number', 'title', 'description', 'category', 'type_demande',
        'priority', 'status', 'validation_status', 'validation_comment',
        'created_by', 'assigned_to', 'commercial_dedie', 'client_name',
        'adresse_client', 'interlocuteur', 'contact_technique', 'lieu_visite',
        'visite_date', 'visite_heure', 'moyen_transport', 'elements_complement',
        'attachment', 'resolved_at', 'validated_by', 'validated_at',
        'refused_by', 'refused_at', 'return_message', 'returned_by',
        'returned_at', 'reformulation_count',
    ];

    protected function casts(): array
    {
        return [
            'visite_date' => 'date',
            'resolved_at' => 'datetime',
            'validated_at' => 'datetime',
            'refused_at' => 'datetime',
            'returned_at' => 'datetime',
        ];
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function validator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'validated_by');
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(TicketAssignment::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class)->orderByDesc('created_at');
    }

    public function interventions(): HasMany
    {
        return $this->hasMany(Intervention::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class);
    }

    public function scopeStatus($query, ?string $status)
    {
        return $status ? $query->where('status', $status) : $query;
    }

    public function scopeCategory($query, ?string $category)
    {
        return $category ? $query->where('category', $category) : $query;
    }

    public function scopePriority($query, ?string $priority)
    {
        return $priority ? $query->where('priority', $priority) : $query;
    }

    public static function generateTicketNumber(): string
    {
        $prefix = 'TCK-'.date('Ymd').'-';
        $last = static::where('ticket_number', 'like', $prefix.'%')
            ->orderByDesc('id')->first();
        $seq = $last ? ((int) substr($last->ticket_number, -4)) + 1 : 1;

        return $prefix.str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
    }
}
