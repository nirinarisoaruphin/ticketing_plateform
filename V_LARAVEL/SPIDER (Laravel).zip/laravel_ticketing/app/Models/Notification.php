<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Notification extends Model
{
    public $timestamps = false;

    public const TYPES = [
        'ticket', 'comment', 'status', 'action', 'message',
        'validation', 'assignation', 'planning', 'general',
    ];

    protected $fillable = ['user_id', 'ticket_id', 'message', 'link', 'type', 'is_read'];

    protected function casts(): array
    {
        return ['is_read' => 'boolean', 'created_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    public function scopeUnread($query)
    {
        return $query->where('is_read', false);
    }
}
