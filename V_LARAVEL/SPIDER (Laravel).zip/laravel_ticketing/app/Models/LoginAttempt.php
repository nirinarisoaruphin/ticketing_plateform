<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoginAttempt extends Model
{
    public $timestamps = false;
    protected $fillable = ['email', 'success', 'ip_address'];

    protected function casts(): array
    {
        return ['success' => 'boolean', 'attempted_at' => 'datetime'];
    }
}
