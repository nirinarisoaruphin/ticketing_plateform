<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Intervention extends Model
{
    public const STATUSES = ['planifiee', 'en_cours', 'en_attente', 'realisee', 'annulee'];

    protected $fillable = [
        'ticket_id', 'technician_id', 'planned_date', 'planned_time',
        'duration', 'status', 'notes',
    ];

    protected function casts(): array
    {
        return ['planned_date' => 'date'];
    }

    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    public function technician(): BelongsTo
    {
        return $this->belongsTo(User::class, 'technician_id');
    }

    public function history(): HasMany
    {
        return $this->hasMany(InterventionHistory::class)->orderByDesc('created_at');
    }
}
