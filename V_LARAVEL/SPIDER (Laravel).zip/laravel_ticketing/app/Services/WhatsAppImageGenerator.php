<?php

namespace App\Services;

use App\Models\Ticket;
use Illuminate\Support\Facades\Storage;

/**
 * Génère une image récapitulative PNG pour un ticket (via GD) et construit
 * l'URL de partage WhatsApp (wa.me) correspondante.
 *
 * Portage du script legacy includes/WhatsAppImageGenerator.php vers Laravel.
 */
class WhatsAppImageGenerator
{
    private int $width = 800;
    private int $height = 600;

    /** @var resource|\GdImage */
    private $image;

    private array $colors = [];

    public const ACTION_LABELS = [
        'resolu' => 'Ticket résolu',
        'en_cours' => 'Ticket en cours',
        'en_attente' => 'Ticket en attente',
        'signaler_probleme' => 'Problème signalé',
        'commentaire' => 'Nouveau commentaire',
        'valide' => 'Ticket validé',
        'refuse' => 'Ticket refusé',
    ];

    public const STATUS_LABELS = [
        'nouveau' => 'Nouveau',
        'assigne' => 'Assigné',
        'en_cours' => 'En cours',
        'en_attente' => 'En attente',
        'resolu' => 'Résolu',
        'cloture' => 'Clôturé',
    ];

    public const PRIORITY_LABELS = [
        'basse' => 'Basse',
        'moyenne' => 'Moyenne',
        'haute' => 'Haute',
        'critique' => 'Critique',
    ];

    public const CATEGORY_LABELS = [
        'support_technique' => 'Support technique',
        'bureau_etude' => "Bureau d'études",
        'sav' => 'SAV',
        'travaux' => 'Travaux',
        'general' => 'Général',
    ];

    public function __construct()
    {
        $this->image = imagecreatetruecolor($this->width, $this->height);

        $this->colors = [
            'bg' => imagecolorallocate($this->image, 255, 255, 255),
            'header_bg' => imagecolorallocate($this->image, 26, 35, 126),
            'header_text' => imagecolorallocate($this->image, 255, 255, 255),
            'text_primary' => imagecolorallocate($this->image, 15, 23, 42),
            'text_secondary' => imagecolorallocate($this->image, 71, 85, 105),
            'text_light' => imagecolorallocate($this->image, 148, 163, 184),
            'border' => imagecolorallocate($this->image, 226, 232, 240),
            'success' => imagecolorallocate($this->image, 16, 185, 129),
            'warning' => imagecolorallocate($this->image, 245, 158, 11),
            'danger' => imagecolorallocate($this->image, 239, 68, 68),
            'info' => imagecolorallocate($this->image, 37, 99, 235),
            'card_bg' => imagecolorallocate($this->image, 248, 250, 252),
            'whatsapp_green' => imagecolorallocate($this->image, 37, 211, 102),
        ];
    }

    /**
     * Génère l'image pour une action sur un ticket, la stocke sur le disque
     * "public" et retourne les infos utiles (chemin, url publique, url wa.me).
     *
     * @return array{path:string, filename:string, url:string, whatsapp_url:string}
     */
    public function generateActionImage(Ticket $ticket, string $actionType, string $senderName, string $content = ''): array
    {
        $this->drawBackground();
        $this->drawHeader($ticket);
        $this->drawActionBanner($actionType, $senderName);
        $this->drawTicketInfo($ticket);
        $this->drawActionMessage($content);
        $this->drawFooter($ticket);

        $filename = 'whatsapp_'.$ticket->ticket_number.'_'.now()->format('Ymd_His').'.png';
        $relativePath = 'whatsapp/'.$filename;

        ob_start();
        imagepng($this->image, null, 9);
        $binary = ob_get_clean();
        imagedestroy($this->image);

        Storage::disk('public')->put($relativePath, $binary);

        return [
            'path' => $relativePath,
            'filename' => $filename,
            'url' => Storage::disk('public')->url($relativePath),
            'whatsapp_url' => $this->getWhatsAppShareUrl($ticket, $actionType, $senderName, $content, $relativePath),
        ];
    }

    private function drawBackground(): void
    {
        imagefill($this->image, 0, 0, $this->colors['bg']);
        imagefilledrectangle($this->image, 0, 0, $this->width, 8, $this->colors['header_bg']);
    }

    private function drawHeader(Ticket $ticket): void
    {
        imagefilledrectangle($this->image, 0, 8, $this->width, 90, $this->colors['header_bg']);

        $iconX = 30;
        $iconY = 30;
        imagefilledellipse($this->image, $iconX + 20, $iconY + 20, 40, 40, $this->colors['whatsapp_green']);

        imagestring($this->image, 5, $iconX + 65, 28, 'Ticket '.$ticket->ticket_number, $this->colors['header_text']);

        $title = $ticket->title ?: 'Sans titre';
        $truncatedTitle = strlen($title) > 40 ? substr($title, 0, 40).'...' : $title;
        imagestring($this->image, 4, $iconX + 65, 52, $truncatedTitle, imagecolorallocate($this->image, 200, 200, 255));

        imagestring($this->image, 3, $this->width - 200, 28, now()->format('d/m/Y H:i'), imagecolorallocate($this->image, 150, 150, 220));
    }

    private function drawActionBanner(string $actionType, string $senderName): void
    {
        $y = 100;
        $height = 70;
        $x = 30;
        $width = $this->width - 60;

        $label = self::ACTION_LABELS[$actionType] ?? 'Action effectuée';
        $color = match ($actionType) {
            'resolu', 'valide' => $this->colors['success'],
            'en_cours' => $this->colors['info'],
            'en_attente' => $this->colors['warning'],
            'signaler_probleme', 'refuse' => $this->colors['danger'],
            default => $this->colors['text_secondary'],
        };

        imagefilledrectangle($this->image, $x, $y, $x + $width, $y + $height, $color);
        imagestring($this->image, 5, $x + 20, $y + 15, $label, $this->colors['bg']);

        $subText = 'par '.$senderName.' · '.now()->format('d/m/Y H:i');
        imagestring($this->image, 3, $x + 20, $y + 42, $subText, imagecolorallocate($this->image, 240, 240, 255));
    }

    private function drawTicketInfo(Ticket $ticket): void
    {
        $y = 190;
        $x = 30;
        $width = $this->width - 60;

        imagefilledrectangle($this->image, $x, $y, $x + $width, $y + 180, $this->colors['card_bg']);
        imagerectangle($this->image, $x, $y, $x + $width, $y + 180, $this->colors['border']);

        $col1X = $x + 20;
        $col2X = $x + 350;
        $labelColor = $this->colors['text_secondary'];
        $valueColor = $this->colors['text_primary'];

        $rowY = $y + 20;
        imagestring($this->image, 3, $col1X, $rowY, 'Statut :', $labelColor);
        imagestring($this->image, 3, $col1X + 120, $rowY, self::STATUS_LABELS[$ticket->status] ?? $ticket->status, $valueColor);

        $rowY += 30;
        imagestring($this->image, 3, $col1X, $rowY, 'Priorité :', $labelColor);
        imagestring($this->image, 3, $col1X + 120, $rowY, self::PRIORITY_LABELS[$ticket->priority] ?? $ticket->priority, $valueColor);

        $rowY += 30;
        imagestring($this->image, 3, $col1X, $rowY, 'Catégorie :', $labelColor);
        imagestring($this->image, 3, $col1X + 120, $rowY, self::CATEGORY_LABELS[$ticket->category] ?? $ticket->category, $valueColor);

        $rowY += 30;
        imagestring($this->image, 3, $col1X, $rowY, 'Assigné à :', $labelColor);
        imagestring($this->image, 3, $col1X + 120, $rowY, $ticket->assignee?->full_name ?? 'Non assigné', $valueColor);

        $rowY += 30;
        imagestring($this->image, 3, $col1X, $rowY, 'Client :', $labelColor);
        imagestring($this->image, 3, $col1X + 120, $rowY, $ticket->client_name ?? 'Non renseigné', $valueColor);

        imagestring($this->image, 3, $col2X, $y + 20, 'Commentaires :', $labelColor);
        imagestring($this->image, 3, $col2X + 130, $y + 20, $ticket->comments()->count().' message(s)', $valueColor);

        imagestring($this->image, 3, $col2X, $y + 50, 'Créé par :', $labelColor);
        imagestring($this->image, 3, $col2X + 130, $y + 50, $ticket->creator?->full_name ?? 'Inconnu', $valueColor);

        imagestring($this->image, 3, $col2X, $y + 80, 'Créé le :', $labelColor);
        imagestring($this->image, 3, $col2X + 130, $y + 80, optional($ticket->created_at)->format('d/m/Y H:i'), $valueColor);
    }

    private function drawActionMessage(string $content): void
    {
        if ($content === '') {
            return;
        }

        $y = 390;
        $x = 30;
        $width = $this->width - 60;

        imagefilledrectangle($this->image, $x, $y, $x + $width, $y + 70, $this->colors['card_bg']);
        imagerectangle($this->image, $x, $y, $x + $width, $y + 70, $this->colors['border']);
        imagestring($this->image, 3, $x + 15, $y + 8, 'Message :', $this->colors['text_secondary']);

        $truncated = strlen($content) > 100 ? substr($content, 0, 100).'...' : $content;
        $lines = explode("\n", wordwrap($truncated, 50, "\n"));
        $lineY = $y + 32;
        foreach ($lines as $line) {
            imagestring($this->image, 3, $x + 15, $lineY, $line, $this->colors['text_primary']);
            $lineY += 18;
            if ($lineY > $y + 65) {
                break;
            }
        }
    }

    private function drawFooter(Ticket $ticket): void
    {
        $y = $this->height - 70;
        $x = 30;
        $width = $this->width - 60;

        imageline($this->image, $x, $y, $x + $width, $y, $this->colors['border']);

        $y += 10;
        imagefilledrectangle($this->image, $this->width - 80, $y - 5, $this->width - 30, $y + 35, $this->colors['whatsapp_green']);

        imagestring($this->image, 3, $x + 20, $y + 5, 'Partagez ce ticket sur WhatsApp', $this->colors['whatsapp_green']);
        imagestring($this->image, 2, $x + 20, $y + 25, 'Plateforme de Ticketing - SPIDER Madagascar', $this->colors['text_light']);
        imagestring($this->image, 3, $this->width - 200, $y + 30, $ticket->ticket_number, $this->colors['text_secondary']);

        imagefilledrectangle($this->image, 0, $this->height - 5, $this->width, $this->height, $this->colors['header_bg']);
    }

    private function getWhatsAppShareUrl(Ticket $ticket, string $actionType, string $senderName, string $content, string $relativePath): string
    {
        $phoneNumber = config('services.whatsapp.number', '261340000001');
        $imageUrl = Storage::disk('public')->url($relativePath);
        $actionLabel = self::ACTION_LABELS[$actionType] ?? 'Action effectuée';
        $ticketUrl = route('tickets.show', $ticket);

        $message = "*Récapitulatif du ticket {$ticket->ticket_number}*\n\n";
        $message .= "*Action :* {$actionLabel}\n";
        $message .= '*Par :* '.$senderName."\n";
        $message .= '*Titre :* '.($ticket->title ?: 'Sans titre')."\n";
        $message .= '*Statut :* '.(self::STATUS_LABELS[$ticket->status] ?? $ticket->status)."\n";
        $message .= '*Priorité :* '.(self::PRIORITY_LABELS[$ticket->priority] ?? $ticket->priority)."\n";
        $message .= '*Catégorie :* '.(self::CATEGORY_LABELS[$ticket->category] ?? $ticket->category)."\n";
        $message .= '*Assigné à :* '.($ticket->assignee?->full_name ?? 'Non assigné')."\n";
        $message .= '*Date :* '.now()->format('d/m/Y à H:i')."\n\n";

        if ($content !== '') {
            $message .= "*Message :*\n".$content."\n\n";
        }

        $message .= '*Lien :* '.$ticketUrl."\n\n";
        $message .= '*Image récapitulative :* '.$imageUrl."\n\n";
        $message .= "---\n";
        $message .= 'Plateforme de Ticketing - SPIDER Madagascar';

        return 'https://wa.me/'.$phoneNumber.'?text='.urlencode($message);
    }
}
