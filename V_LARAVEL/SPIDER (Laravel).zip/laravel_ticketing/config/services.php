<?php

return [

    /*
    |--------------------------------------------------------------------------
    | WhatsApp
    |--------------------------------------------------------------------------
    |
    | Numéro utilisé par défaut pour la génération des liens de partage
    | WhatsApp (wa.me) depuis un ticket.
    |
    */
    'whatsapp' => [
        'number' => env('WHATSAPP_NUMBER', '261340000001'),
    ],

];
