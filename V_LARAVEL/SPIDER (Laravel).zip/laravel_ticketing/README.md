# Plateforme Ticketing — Version Laravel

Portage complet du projet PHP "ticketing_plateform" (framework maison) vers **Laravel 11**.

## Modules portés
- Authentification (login/register/changement de mot de passe forcé)
- Tickets (CRUD, validation/refus, retour pour reformulation, commentaires)
- Planning des interventions (création, report, historique, notes)
- Notifications
- Messages (commentaires transverses)
- Historique des actions (logs)
- Export CSV des tickets
- Gestion des utilisateurs et rôles (admin, coordinateur, responsables, chargés d'étude, commercial)

## Installation

```bash
composer install
cp .env.example .env
php artisan key:generate
# Configurer DB_* dans .env puis :
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Comptes de démonstration créés par le seeder (mot de passe `admin123`, à changer à la première connexion) :
- ruphin@spider.mg (admin)
- mikajy@spider.mg (coordinateur)

## Structure
- `app/Models` — Eloquent (User, Ticket, TicketAssignment, Comment, Notification, Intervention, InterventionHistory, Log, EmailQueue, LoginAttempt)
- `app/Http/Controllers` — Auth, Dashboard, Ticket, User, Planning, Messages, Notification, Historique, Export, Profile
- `app/Http/Middleware` — EnsureRole (contrôle d'accès par rôle), MustChangePassword
- `database/migrations` — reprennent fidèlement le schéma SQL d'origine (`sql/database.sql`)
- `resources/views` — Blade + Tailwind (CDN), un gabarit par vue PHP d'origine

## Notes de portage
- Les mots de passe utilisent le hachage natif Laravel (`Hash::make`), compatible bcrypt avec les hashs existants issus de `password_hash()`.
- Le SSE temps réel (`sse.php`) et les workers d'emails custom (`EmailManager`, `Mailer`) sont remplacés par les mécanismes standards Laravel (queues, `Illuminate\Support\Facades\Mail`) à brancher selon vos besoins (Redis/queue table `jobs` à ajouter si vous activez les files d'attente).
- Le cron `planning_automation.php` peut être reproduit via `routes/console.php` + le scheduler Laravel (`php artisan schedule:work`).
