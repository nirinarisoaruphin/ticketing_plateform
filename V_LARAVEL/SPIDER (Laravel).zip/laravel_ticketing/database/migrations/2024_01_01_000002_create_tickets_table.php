<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_number', 50)->unique();
            $table->string('title', 255);
            $table->text('description')->nullable();
            $table->enum('category', ['support_technique', 'bureau_etude', 'sav', 'travaux'])
                ->default('support_technique')->index();
            $table->enum('type_demande', [
                'etude', 'visite', 'visite_etude', 'visite_etude_installation', 'panne',
                'installation', 'maintenance', 'sav', 'travaux', 'demande_info', 'autre',
            ])->default('etude');
            $table->enum('priority', ['basse', 'moyenne', 'haute', 'critique'])->default('moyenne')->index();
            $table->enum('status', ['nouveau', 'assigne', 'en_cours', 'en_attente', 'resolu', 'cloture'])
                ->default('nouveau')->index();
            $table->enum('validation_status', ['en_attente', 'valide', 'refuse'])->default('en_attente');
            $table->text('validation_comment')->nullable();
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $table->string('commercial_dedie', 100)->nullable();
            $table->string('client_name', 100)->nullable();
            $table->text('adresse_client')->nullable();
            $table->string('interlocuteur', 100)->nullable();
            $table->string('contact_technique', 100)->nullable();
            $table->string('lieu_visite', 255)->nullable();
            $table->date('visite_date')->nullable();
            $table->time('visite_heure')->nullable();
            $table->string('moyen_transport', 50)->nullable();
            $table->text('elements_complement')->nullable();
            $table->string('attachment', 255)->nullable();
            $table->dateTime('resolved_at')->nullable();
            $table->foreignId('validated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->dateTime('validated_at')->nullable();
            $table->foreignId('refused_by')->nullable()->constrained('users')->nullOnDelete();
            $table->dateTime('refused_at')->nullable();
            $table->text('return_message')->nullable();
            $table->foreignId('returned_by')->nullable()->constrained('users')->nullOnDelete();
            $table->dateTime('returned_at')->nullable();
            $table->integer('reformulation_count')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->nullable()->useCurrentOnUpdate();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
