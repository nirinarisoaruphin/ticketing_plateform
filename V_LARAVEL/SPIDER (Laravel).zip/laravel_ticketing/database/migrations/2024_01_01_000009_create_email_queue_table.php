<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('email_queue', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ticket_id')->nullable()->constrained('tickets')->nullOnDelete();
            $table->string('ticket_number', 50)->nullable();
            $table->string('recipient_email', 100)->nullable();
            $table->string('recipient_name', 100)->nullable();
            $table->string('subject', 255)->nullable();
            $table->text('message')->nullable();
            $table->enum('status', ['pending', 'sent', 'failed'])->default('pending')->index();
            $table->text('error')->nullable();
            $table->timestamp('created_at')->useCurrent()->index();
            $table->dateTime('processed_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('email_queue');
    }
};
