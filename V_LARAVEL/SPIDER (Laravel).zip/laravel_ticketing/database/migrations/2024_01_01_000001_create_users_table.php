<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username', 50)->unique();
            $table->string('email', 100)->unique();
            $table->string('password', 255);
            $table->string('full_name', 100);
            $table->string('phone', 20)->nullable();
            $table->enum('role', [
                'admin',
                'coordinateur',
                'responsable_support_technique',
                'responsable_sav',
                'responsable_travaux',
                'commercial',
                'charge_etude_electricite',
                'charge_etude_courant_faible',
                'charge_etude_climatisation',
            ])->default('commercial')->index();
            $table->boolean('must_change_password')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->nullable()->useCurrentOnUpdate();
            $table->rememberToken();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
