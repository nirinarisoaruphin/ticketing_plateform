<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['username' => 'ruphin', 'email' => 'ruphin@spider.mg', 'full_name' => 'Ruphin - Administrateur', 'role' => 'admin'],
            ['username' => 'mikajy', 'email' => 'mikajy@spider.mg', 'full_name' => 'Mikajy - Coordinateur', 'role' => 'coordinateur'],
        ];

        foreach ($users as $u) {
            User::updateOrCreate(
                ['email' => $u['email']],
                [
                    'username' => $u['username'],
                    'full_name' => $u['full_name'],
                    'role' => $u['role'],
                    'password' => Hash::make('admin123'),
                    'must_change_password' => true,
                    'active' => true,
                ]
            );
        }
    }
}
