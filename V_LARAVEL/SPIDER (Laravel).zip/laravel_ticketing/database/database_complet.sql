-- =====================================================================
-- Plateforme Ticketing — Script SQL complet (MySQL 8 / MariaDB 10.4+)
-- Correspond exactement aux migrations Laravel du dossier
-- database/migrations/. À utiliser en alternative à `php artisan migrate`
-- (ex: import direct via phpMyAdmin / CLI mysql).
-- =====================================================================

SET NAMES utf8mb4;

-- On repart d'une base totalement vierge : plus fiable que DROP TABLE
-- quand d'anciennes tables ont des contraintes FK qui ne portent pas les
-- mêmes noms que celles créées ci-dessous (cause de l'erreur #3730).
DROP DATABASE IF EXISTS ticketing_plateform;
CREATE DATABASE ticketing_plateform
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ticketing_plateform;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- Table: users
-- ---------------------------------------------------------------------
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NULL,
    `role` ENUM(
        'admin','coordinateur','responsable_support_technique','responsable_sav',
        'responsable_travaux','commercial','charge_etude_electricite',
        'charge_etude_courant_faible','charge_etude_climatisation'
    ) NOT NULL DEFAULT 'commercial',
    `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `remember_token` VARCHAR(100) NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_username_unique` (`username`),
    UNIQUE KEY `users_email_unique` (`email`),
    KEY `users_role_index` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: tickets
-- ---------------------------------------------------------------------
CREATE TABLE `tickets` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ticket_number` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT NULL,
    `category` ENUM('support_technique','bureau_etude','sav','travaux') NOT NULL DEFAULT 'support_technique',
    `type_demande` ENUM(
        'etude','visite','visite_etude','visite_etude_installation','panne',
        'installation','maintenance','sav','travaux','demande_info','autre'
    ) NOT NULL DEFAULT 'etude',
    `priority` ENUM('basse','moyenne','haute','critique') NOT NULL DEFAULT 'moyenne',
    `status` ENUM('nouveau','assigne','en_cours','en_attente','resolu','cloture') NOT NULL DEFAULT 'nouveau',
    `validation_status` ENUM('en_attente','valide','refuse') NOT NULL DEFAULT 'en_attente',
    `validation_comment` TEXT NULL,
    `created_by` BIGINT UNSIGNED NOT NULL,
    `assigned_to` BIGINT UNSIGNED NULL,
    `commercial_dedie` VARCHAR(100) NULL,
    `client_name` VARCHAR(100) NULL,
    `adresse_client` TEXT NULL,
    `interlocuteur` VARCHAR(100) NULL,
    `contact_technique` VARCHAR(100) NULL,
    `lieu_visite` VARCHAR(255) NULL,
    `visite_date` DATE NULL,
    `visite_heure` TIME NULL,
    `moyen_transport` VARCHAR(50) NULL,
    `elements_complement` TEXT NULL,
    `attachment` VARCHAR(255) NULL,
    `resolved_at` DATETIME NULL,
    `validated_by` BIGINT UNSIGNED NULL,
    `validated_at` DATETIME NULL,
    `refused_by` BIGINT UNSIGNED NULL,
    `refused_at` DATETIME NULL,
    `return_message` TEXT NULL,
    `returned_by` BIGINT UNSIGNED NULL,
    `returned_at` DATETIME NULL,
    `reformulation_count` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `tickets_ticket_number_unique` (`ticket_number`),
    KEY `tickets_category_index` (`category`),
    KEY `tickets_priority_index` (`priority`),
    KEY `tickets_status_index` (`status`),
    CONSTRAINT `tickets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `tickets_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `tickets_validated_by_foreign` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `tickets_refused_by_foreign` FOREIGN KEY (`refused_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `tickets_returned_by_foreign` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: ticket_assignments
-- ---------------------------------------------------------------------
CREATE TABLE `ticket_assignments` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ticket_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `assigned_by` BIGINT UNSIGNED NULL,
    `assigned_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    UNIQUE KEY `ticket_assignments_ticket_id_user_id_unique` (`ticket_id`, `user_id`),
    CONSTRAINT `ticket_assignments_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
    CONSTRAINT `ticket_assignments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `ticket_assignments_assigned_by_foreign` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: comments
-- ---------------------------------------------------------------------
CREATE TABLE `comments` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ticket_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `content` TEXT NOT NULL,
    `action_type` VARCHAR(50) NULL,
    `notify_roles` VARCHAR(255) NULL,
    `is_action` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `comments_created_at_index` (`created_at`),
    CONSTRAINT `comments_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
    CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: notifications
-- ---------------------------------------------------------------------
CREATE TABLE `notifications` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `ticket_id` BIGINT UNSIGNED NULL,
    `message` TEXT NOT NULL,
    `link` VARCHAR(255) NULL,
    `type` ENUM(
        'ticket','comment','status','action','message',
        'validation','assignation','planning','general'
    ) NOT NULL DEFAULT 'general',
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `notifications_is_read_index` (`is_read`),
    KEY `notifications_created_at_index` (`created_at`),
    CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `notifications_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: interventions
-- ---------------------------------------------------------------------
CREATE TABLE `interventions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ticket_id` BIGINT UNSIGNED NOT NULL,
    `technician_id` BIGINT UNSIGNED NOT NULL,
    `planned_date` DATE NOT NULL,
    `planned_time` TIME NOT NULL,
    `duration` INT NOT NULL DEFAULT 60,
    `status` ENUM('planifiee','en_cours','en_attente','realisee','annulee') NOT NULL DEFAULT 'planifiee',
    `notes` TEXT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `interventions_planned_date_index` (`planned_date`),
    CONSTRAINT `interventions_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
    CONSTRAINT `interventions_technician_id_foreign` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: intervention_history
-- ---------------------------------------------------------------------
CREATE TABLE `intervention_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `intervention_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NULL,
    `action` VARCHAR(50) NOT NULL,
    `details` TEXT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    CONSTRAINT `intervention_history_intervention_id_foreign` FOREIGN KEY (`intervention_id`) REFERENCES `interventions` (`id`) ON DELETE CASCADE,
    CONSTRAINT `intervention_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: logs
-- ---------------------------------------------------------------------
CREATE TABLE `logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `details` TEXT NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(255) NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `logs_action_index` (`action`),
    KEY `logs_created_at_index` (`created_at`),
    CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: email_queue
-- ---------------------------------------------------------------------
CREATE TABLE `email_queue` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ticket_id` BIGINT UNSIGNED NULL,
    `ticket_number` VARCHAR(50) NULL,
    `recipient_email` VARCHAR(100) NULL,
    `recipient_name` VARCHAR(100) NULL,
    `subject` VARCHAR(255) NULL,
    `message` TEXT NULL,
    `status` ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
    `error` TEXT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `processed_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `email_queue_status_index` (`status`),
    KEY `email_queue_created_at_index` (`created_at`),
    CONSTRAINT `email_queue_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: login_attempts
-- ---------------------------------------------------------------------
CREATE TABLE `login_attempts` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(100) NOT NULL,
    `success` TINYINT(1) NOT NULL DEFAULT 0,
    `ip_address` VARCHAR(45) NULL,
    `attempted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `login_attempts_email_index` (`email`),
    KEY `login_attempts_attempted_at_index` (`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table: sessions (pilote SESSION_DRIVER=database)
-- ---------------------------------------------------------------------
CREATE TABLE `sessions` (
    `id` VARCHAR(255) NOT NULL,
    `user_id` BIGINT UNSIGNED NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` TEXT NULL,
    `payload` LONGTEXT NOT NULL,
    `last_activity` INT NOT NULL,
    PRIMARY KEY (`id`),
    KEY `sessions_user_id_index` (`user_id`),
    KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table technique Laravel (nécessaire si migrate --seed est déjà passé
-- une fois ; conservée ici pour que l'import direct soit autonome)
-- ---------------------------------------------------------------------
CREATE TABLE `migrations` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `migration` VARCHAR(255) NOT NULL,
    `batch` INT NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2024_01_01_000001_create_users_table', 1),
('2024_01_01_000002_create_tickets_table', 1),
('2024_01_01_000003_create_ticket_assignments_table', 1),
('2024_01_01_000004_create_comments_table', 1),
('2024_01_01_000005_create_notifications_table', 1),
('2024_01_01_000006_create_interventions_table', 1),
('2024_01_01_000007_create_intervention_history_table', 1),
('2024_01_01_000008_create_logs_table', 1),
('2024_01_01_000009_create_email_queue_table', 1),
('2024_01_01_000010_create_login_attempts_table', 1),
('2024_01_01_000011_create_sessions_table', 1);

-- ---------------------------------------------------------------------
-- Données de démonstration (identiques à database/seeders/DatabaseSeeder.php)
-- Mot de passe pour les deux comptes : admin123  (à changer à la 1ère connexion,
-- must_change_password = 1)
-- ---------------------------------------------------------------------
INSERT INTO `users`
    (`username`, `email`, `password`, `full_name`, `role`, `must_change_password`, `active`)
VALUES
    ('ruphin', 'ruphin@spider.mg', '$2y$10$DZ2fUyTFpEOM/GcAJ1trHuiEhoS.VQcQvqoy4YyV9Cms72dycdKX.', 'Ruphin - Administrateur', 'admin', 1, 1),
    ('mikajy', 'mikajy@spider.mg', '$2y$10$DZ2fUyTFpEOM/GcAJ1trHuiEhoS.VQcQvqoy4YyV9Cms72dycdKX.', 'Mikajy - Coordinateur', 'coordinateur', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
